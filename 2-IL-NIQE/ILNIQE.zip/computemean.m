function val = computemean(patch)
data = patch.data;
val = mean2(data);